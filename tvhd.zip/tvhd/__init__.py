# -*- coding: utf-8 -*-
"""
Tvhd Module for VietMediaF
Auto-upgraded by Module Manager on 2025-07-28 11:29:39
"""

__version__ = "1.1.0"
__author__ = "VietMediaF Team"
__module_name__ = "tvhd"

# Import main functionality
try:
    from .main import *
except ImportError:
    pass

# Import other module files dynamically
import os
current_dir = os.path.dirname(__file__)
try:
    for file in os.listdir(current_dir):
        if file.endswith('.py') and file not in ['__init__.py', 'main.py'] and not file.endswith('.backup'):
            module_file = file[:-3]  # Remove .py extension
            try:
                exec(f"from .{module_file} import *")
            except ImportError:
                pass
except Exception:
    pass
