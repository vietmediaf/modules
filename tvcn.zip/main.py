#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Sao chép nội dung từ tvcine.py sang main.py
from .tvcine import *
