#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Re-export tất cả các symbols từ module main.py
from .main import *

# Tạo alias để các module khác có thể import tvcn
import sys
sys.modules['tvcn'] = sys.modules[__name__]
