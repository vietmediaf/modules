#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Import tất cả từ tvcine.py (có hàm receive)
from .tvcine import *

# Import tất cả từ thuviencine.py (có hàm get_thuviencine_top)
from .thuviencine import *
